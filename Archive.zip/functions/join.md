[@frost/frost-web](../modules.md) / [Exports](../modules.md) / join

# Function: join

▸ **join**(...`args`): `string`

#### Parameters

| Name | Type |
| :------ | :------ |
| `...args` | `string`[] |

#### Returns

`string`
