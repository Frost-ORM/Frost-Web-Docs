[@frost/frost-web](../modules.md) / [Exports](../modules.md) / getIndices

# Function: getIndices

▸ **getIndices**(): `string`

#### Returns

`string`

a JSON String for the indices to be added to the Firebase Realtime Database
