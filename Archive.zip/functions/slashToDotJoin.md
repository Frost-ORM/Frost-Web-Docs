[@frost/frost-web](../modules.md) / [Exports](../modules.md) / slashToDotJoin

# Function: slashToDotJoin

▸ **slashToDotJoin**(...`args`): `string`

#### Parameters

| Name | Type |
| :------ | :------ |
| `...args` | `string`[] |

#### Returns

`string`
