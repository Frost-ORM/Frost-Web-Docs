[@frost/frost-web](../modules.md) / [Exports](../modules.md) / IFrostObject

# Type alias: IFrostObject<T\>

Ƭ **IFrostObject**<`T`\>: `Omit`<typeof [`FrostObject`](../classes/FrostObject.md), ``"new"``\> & {}

#### Type parameters

| Name | Type |
| :------ | :------ |
| `T` | extends [`FrostObject`](../classes/FrostObject.md) |
