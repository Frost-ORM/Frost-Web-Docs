[@frost/frost-web](../modules.md) / [Exports](../modules.md) / Include

# Type alias: Include

Ƭ **Include**: `string`[] \| `undefined`

an array of the property names with relations that you want to be included in the fetch request.

if the array is empty or undefined no relations will be included
