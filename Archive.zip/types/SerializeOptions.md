[@frost/frost-web](../modules.md) / [Exports](../modules.md) / SerializeOptions

# Type alias: SerializeOptions<T, P\>

Ƭ **SerializeOptions**<`T`, `P`\>: [`SerializeOptionsWithNullCall`](SerializeOptionsWithNullCall.md)<`T`, `P`\> \| [`SerializeOptionsWithoutNullCall`](SerializeOptionsWithoutNullCall.md)<`T`, `P`\>

A union type of [SerializeOptionsWithoutNullCall<T, P\>](SerializeOptionsWithoutNullCall.md) and [SerializeOptionsWithNullCall<T, P\>](SerializeOptionsWithNullCall.md)

**`See`**

 - [SerializeOptionsWithoutNullCall<T, P\>](SerializeOptionsWithoutNullCall.md)
 - [SerializeOptionsWithNullCall<T, P\>](SerializeOptionsWithNullCall.md)

#### Type parameters

| Name |
| :------ |
| `T` |
| `P` |
