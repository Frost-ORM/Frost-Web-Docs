[@frost/frost-web](../modules.md) / [Exports](../modules.md) / FrostEntityDecoratorOptions

# Type alias: FrostEntityDecoratorOptions

Ƭ **FrostEntityDecoratorOptions**: `Object`

#### Type declaration

| Name | Type |
| :------ | :------ |
| `collectionPath` | `string` |
